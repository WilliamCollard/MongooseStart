console.log("inside of people.js");

const mongoose = require("mongoose");

const PeopleSchema = new mongoose.Schema({
  name: {type: String, required: [true, "People must have a name"]},
});

mongoose.model('People', PeopleSchema);

module.exports = PeopleSchema;
