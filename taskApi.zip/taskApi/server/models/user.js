console.log("inside of user.js");

const mongoose = require("mongoose");
const PeopleSchema = require("./people.js");

const UserSchema = new mongoose.Schema({
  name: {type: String, required: [true, "User must have a name"]},
  peoples: [PeopleSchema]
});

mongoose.model('User', UserSchema);
