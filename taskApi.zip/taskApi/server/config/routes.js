console.log("inside of routes.js");

const Peoples = require("../controllers/peoples");
const Users = require("../controllers/users");

module.exports = function(app){
  app.get("/users", Users.getAll);
  app.get("/peoples", Peoples.getAll);
  app.post("/users", Users.create);
  app.post("/peoples/:id", Peoples.create);
  app.put("/peoples/:id", Peoples.update);
  app.delete("/peoples/:id", Peoples.delete);
}
