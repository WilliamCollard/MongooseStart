console.log("inside of peoples.js");

const mongoose = require("mongoose");
const People = mongoose.model("People");
const User = mongoose.model("User");

class Peoples {
  create(req, res){
    let people = new People(req.body);
    people.save(function(err){
      if(err){
        res.json({"status": "not ok", "errors": err});
      }else{
        User.findOneAndUpdate({_id: req.params.id}, {$push: {peoples: people}}, function(err, data){
          if(err){
            res.json({"status": "not ok", "errors": err});
          }else{
            res.json({"status": "ok", "data": data});
          }
        });
      }
    });
  }
  getAll(req, res){
    People.find({}, function(err, peoples){
      if(err){
        res.json({"status": "not ok", "errors": err});
      }else{
        res.json({"status": "ok", "peoples": peoples});
      }
    });
  }
  update(req, res) {
    People.findOneAndUpdate({_id: req.params.id}, {$set: {name: req.body.name}}, function(err, data){
      if(err){
        res.json({"status": "not ok", "errors": err});
      }else{
        res.json({"status": "ok", "data": data});
      }
    });
  }
  delete(req, res) {
    People.findByIdAndRemove({_id: req.params.id}, function(err, data){
      if(err){
        res.json({"status": "not ok", "errors": err});
      }else{
        res.json({"status": "ok", "data": data});
      }
    });
  }
}
module.exports = new Peoples();
