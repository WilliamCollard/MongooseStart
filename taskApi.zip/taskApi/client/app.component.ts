import { Component } from '@angular/core';
import { PeopleService } from './people.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'MEAN';
  users = [];

  constructor(private _peopleService:PeopleService){}

  ngOnInit(){
    this._peopleService.getUsers().subscribe((data) => {
      console.log(data);
      this.users = data['users'];
    });
  }
}
