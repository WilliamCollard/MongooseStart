console.log("inside of server.js");

const express = require("express"),
           bp = require("body-parser"),
          app = express(),
      db_name = "peopleshop",
         port = 8888;

app.use(bp.json());
app.use(express.static( __dirname + '/client/dist/client' ));

require("./server/config/mongoose")(db_name);
require("./server/config/routes")(app);

app.listen(port, function() {
    console.log();
});
